package homework;

import java.util.Scanner;

public class MapStr {
	// ��������Ƿ�Ϸ�
	public String cheakInput(int row, int col, String str) {
		if (row > 100 || col > 100) {
			return "Incorrect mesh size.";
		}
		if (row * col != str.length()) {
			return "Data mismatch";
		}
		for (int i = 0; i < str.length(); i++) {
			char unit = str.charAt(i);
			if (unit != 'R' && unit != 'G' && unit != 'F' && unit != 'D') {
				return "Invalid cell type";
			}
		}
		return null;
	}

	public String dangerMap(char[][] charArray, int row, int col) {
		String result = "";
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				if (charArray[i][j] == 'D') {
					if (i - 1 >= 0 && charArray[i - 1][j] != 'D') {
						charArray[i - 1][j] = 'W';
					}
					if (i - 1 >= 0 && j - 1 >= 0 && charArray[i - 1][j - 1] != 'D') {
						charArray[i - 1][j - 1] = 'W';
					}
					if (i - 1 >= 0 && j + 1 < col && charArray[i - 1][j + 1] != 'D') {
						charArray[i - 1][j + 1] = 'W';
					}
					if (j - 1 >= 0 && charArray[i][j - 1] != 'D') {
						charArray[i][j - 1] = 'W';
					}
					if (j + 1 < col && charArray[i][j + 1] != 'D') {
						charArray[i][j + 1] = 'W';
					}
					if (i + 1 < row && charArray[i + 1][j] != 'D') {
						charArray[i + 1][j] = 'W';
					}
					if (i + 1 < row && j - 1 >= 0 && charArray[i + 1][j - 1] != 'D') {
						charArray[i + 1][j - 1] = 'W';
					}
					if (i + 1 < row && j + 1 < col && charArray[i + 1][j + 1] != 'D') {
						charArray[i + 1][j + 1] = 'W';
					}
				}
			}
		}
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				result += charArray[i][j];
			}
			result += '\n';
		}

		return result;
	}

	public String getMap(int row, int col, String str) {
		String checkResult;
		if ((checkResult = cheakInput(row, col, str)) != null) {
			return checkResult;
		} else {
			char[][] mapArray = new char[row][col];
			int strIndex = 0; // �����ַ�������
			int rNum = 0, cNum = 0; // �кš��к�

			while (rNum < row) {
				if ((rNum & 1) == 0) { // ż����
					cNum = 0;
					while (cNum < col) {
						mapArray[rNum][cNum++] = str.charAt(strIndex++);
					}
				} else {
					cNum = col - 1;
					while (cNum >= 0) {
						mapArray[rNum][cNum--] = str.charAt(strIndex++);
					}
				}
				rNum++;
			}
			return dangerMap(mapArray, row, col);
		}
	}

	public static void main(String[] args) {
		Scanner scaner = new Scanner(System.in);
		int row = scaner.nextInt();
		int col = scaner.nextInt();
		String str = null;
		if (scaner.hasNext()) {
			str = scaner.next();
		}
		scaner.close();

		String result = new MapStr().getMap(row, col, str);
		System.out.println(result);
	}

}
