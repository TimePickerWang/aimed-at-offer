package homework;

import org.junit.Assert;
import org.junit.Test;

public class MapStrTest {
	@Test
	public void test1() { // ��֤������ȷ������·��ؽ���Ƿ���ȷ
		int row = 4;
		int col = 6;
		String str = "GRRGGGGGGRFFFFRGGFFGRRFF";
		String map = new MapStr().getMap(row, col, str);
		String rightRes = "GRRGGG\n"
						+ "FFRGGG\n"
						+ "FFRGGF\n"
						+ "FFRRGF\n";
		Assert.assertEquals(map, rightRes);
	}
	
	@Test
	public void test2() { // ��֤������ȷת���ɺ��ʵ�̽�������Сʱ�ķ������
		int row = 102;
		int col = 8;
		String str = "GRRGGGGGGRFFFFRGGFFGRRFF";
		String map = new MapStr().getMap(row, col, str);
		String rightRes = "Incorrect mesh size.";
		Assert.assertEquals(map, rightRes);
	}
	
	@Test
	public void test3() { // ��֤̽����ַ������˲��Ϸ��ַ������
		int row = 4;
		int col = 6;
		String str = "GRBBGGGGAAFFFFRGGFFGRRFF";
		String map = new MapStr().getMap(row, col, str);
		String rightRes = "Invalid cell type";
		Assert.assertEquals(map, rightRes);
	}
	
	@Test
	public void test4() { // ��֤̽����ַ������Ⱥ�̽�������С��һ�µ����
		int row = 2;
		int col = 8;
		String str = "GRRGGGGGGRFFFFRGGFFGRRFF";
		String map = new MapStr().getMap(row, col, str);
		String rightRes = "Data mismatch";
		Assert.assertEquals(map, rightRes);
	}
	
	
	
	
	@Test
	public void test5() {
		int row = 4;
		int col = 6;
		String str = "GRRGGGGGDRFFFFRGGFFGRRFF";
		String map = new MapStr().getMap(row, col, str);
		String rightRes = "GRWWWG\n"
				        + "FFWDWG\n"
				        + "FFWWWF\n"
				        + "FFRRGF\n";
		Assert.assertEquals(map, rightRes);
	}
	
	
	@Test
	public void test6() {
		int row = 4;
		int col = 6;
		String str = "GRDGGG"
				   + "GGGRFF"
				   + "FFRGGF"
				   + "FGRRFF";
		String map = new MapStr().getMap(row, col, str);
		String rightRes = "GWDWGG\n"
				        + "FWWWGG\n"
				        + "FFRGGF\n"
				        + "FFRRGF\n";
		Assert.assertEquals(map, rightRes);
	}
	
	
	@Test
	public void test7() {
		int row = 4;
		int col = 6;
		String str = "GRRGGG"
				   + "GGGDDF"
				   + "FFDGGF"
				   + "FGRRFF";
		String map = new MapStr().getMap(row, col, str);
		String rightRes = "WWWWGG\n"
				        + "WDDWGG\n"
				        + "WWDWGF\n"
				        + "FWWWGF\n";
		Assert.assertEquals(map, rightRes);
	}
	
	
	
	
}
